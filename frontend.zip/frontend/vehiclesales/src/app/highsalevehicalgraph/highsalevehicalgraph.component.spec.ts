import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HighsalevehicalgraphComponent } from './highsalevehicalgraph.component';

describe('HighsalevehicalgraphComponent', () => {
  let component: HighsalevehicalgraphComponent;
  let fixture: ComponentFixture<HighsalevehicalgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HighsalevehicalgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HighsalevehicalgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
