import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { RegistrationComponent } from './registration/registration.component';

import { HighsalevehicalgraphComponent } from './highsalevehicalgraph/highsalevehicalgraph.component';

import { SearchscreenComponent } from './searchscreen/searchscreen.component';
import { ResultscreenComponent } from './resultscreen/resultscreen.component'

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'loginsuccess',component:LoginsuccessComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'login',component:LoginComponent},
  {path:'HighsalevehicalgraphComponent',component:HighsalevehicalgraphComponent},

  {path:'SearchscreenComponent',component:SearchscreenComponent},
  {path:'ResultscreenComponent',component:ResultscreenComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
