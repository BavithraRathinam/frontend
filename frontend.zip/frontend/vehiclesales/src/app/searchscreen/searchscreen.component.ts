import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Graph} from '../highsalevehicalgraph/graph-model';

@Component({
  selector: 'app-searchscreen',
  templateUrl: './searchscreen.component.html',
  styleUrls: ['./searchscreen.component.css']
})
export class SearchscreenComponent implements OnInit {

  model:string[]=['--select--'];
  series:string[]=['--select--'];
  modelYear:string[]=['--select--'];
  accessory=[];
  searchscreenForm: FormGroup;
  smodelyear:string;
  sseries:string;
  smodel:string;
  array:any[];
  display:boolean=false;

  constructor(private formBuild:FormBuilder,
    private http:HttpClient) {
      const promiseSeries = new Promise((resolve, reject) => {
        this.http.get<string[]>('http://localhost:8081/seriesModelService/series/')
        .toPromise().then((res: any) => {
            this.series = [...res];},
            err => { reject(err);});
        });
   }

  ngOnInit(): void {
    
    this.searchscreenForm=this.formBuild.group({
      'series':['',Validators.required],
      'modelYear':['',Validators.required],
      'model':['',Validators.required],
      'accessory':new FormArray([]),
      'from':['',Validators.required],
      'to':['',Validators.required]
    });
  }
  
  get accessoryFormArray(){
    return this.searchscreenForm.controls.accessory as FormArray;
  }

  s(series:any){
    this.sseries=series;
    const promiseSeries = new Promise((resolve, reject) => {
        this.http.get<string[]>('http://localhost:8081/seriesModelService/modelyear/'+this.sseries)
        .toPromise().then((res: any) => {
            this.modelYear = [...res];},
            err => { reject(err);});
        });
    const promiseAccessory = new Promise((resolve, reject) => {
    this.http.get<string[]>('http://localhost:8081/seriesModelService/modelcode/'+this.sseries)
    .toPromise().then((res: any) => {
        this.model = res;},
        err => { reject(err);});
    });
  }
    

  my(modelYear:any){
    this.smodelyear=modelYear;
    const promiseAccessory = new Promise((resolve, reject) => {
      this.http.get<string[]>('http://localhost:8081/seriesModelService/modelcode/'
      +this.sseries+'/'+this.smodelyear)
      .toPromise().then((res: any) => {
          this.model = res;},
          err => { reject(err);});
      });
  }

  mc(model:any){
    this.smodel=model;
    const promiseAccessory = new Promise((resolve, reject) => {
      this.http.get<string[]>('http://localhost:8081/seriesModelService/accessory/'+this.smodel)
      .toPromise().then((res: any) => {
          this.accessory = res;
          console.log(this.accessory);
          res.forEach(()=>this.accessoryFormArray.push(new FormControl(false)));},
          err => { reject(err);});
      });
  }

  onSumbitSearch(){
    console.log(this.searchscreenForm.value.from);
    let str='http://localhost:9090/accessoryService/sales/'+this.searchscreenForm.value.from+'/'+
    this.searchscreenForm.value.to+'/'+this.searchscreenForm.value.series+':'+
    this.searchscreenForm.value.modelYear+':'+this.searchscreenForm.value.model;
    console.log(str);
    console.log(this.getPosts(str));
    this.display=true;
  }

  getPosts(api) {
    console.log("ram");
    const promise = new Promise((resolve, reject) => {
      const apiURL = api;
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((res: any) => {
          // Success
          this.array = res.map((res: any) => {
           //console.log(res);
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            // Error
            reject(err);
          }
        );
    });
    return promise;
  }
}
